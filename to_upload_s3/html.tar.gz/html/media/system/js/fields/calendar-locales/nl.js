window.JoomlaCalLocale = {
	today : "Vandaag",
	weekend : [0, 6],
	wk : "wk",
	time : "Tijd:",
	days : ["Zondag", "Maandag", "Dinsdag", "Woensdag", "Donderdag", "Vrijdag", "Zaterdag"],
	shortDays : ["Zon", "Maa", "Din", "Woe", "Don", "Vri", "Zat"],
	months : ["Januari", "Februari", "Maart", "April", "Mei", "Juni", "Juli", "Augustus", "September", "Oktober", "November", "December"],
	shortMonths : ["Jan", "Feb", "Maa", "Apr", "Mei", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dec"],
	AM : "AM",
	PM :  "PM",
	am : "am",
	pm : "pm",
	dateType : "gregorian",
	minYear : 1900,
	maxYear : 2100,
	exit: "Sluiten",
	clear: "Legen"
};